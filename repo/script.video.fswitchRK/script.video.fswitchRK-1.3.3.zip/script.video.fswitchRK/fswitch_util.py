import os
import sys
import platform
import time
import subprocess
import xbmc
import xbmcaddon
import fswitch_config as fsconfig
import fswitch_configutil as fsconfigutil

def getSourceFPS():
# function for getting for source frame rate from the XBMC log file

    # initialize constants
    refVideoOpen = 'NOTICE: DVDPlayer: Opening: '
    refVideoFPSstart = 'NOTICE:  fps: '
    refVideoFPSend = ', pwidth: '
    
    # initialize return values
    videoFileName = None
    videoFPSValue = None
    
    # get location of log file
    if 'SAMSUNG rk3188' in fsconfig.osPlatform:
        logFileName = xbmc.translatePath('special://temp/XBMC.log')
    
    elif fsconfig.osPlatform == 'Windows 7':
        logFileName = xbmc.translatePath('special://home\XBMC.log')
    
    else:
        return videoFileName, videoFPSValue
    
    # wait 0.40 second for log file to update (with debug on W7: 0.35 not quite long enough for some files)
    xbmc.sleep(400)
    
    # open log file as read only
    with open(logFileName, 'r') as logFile:
        
        # move pointer to the EOF
        logFile.seek(0, 2)
        
        # get pointer location as the file size
        logFileSize = logFile.tell()
        
        # move pointer to 40k characters before EOF (or to BOF)   
        logFile.seek(max(logFileSize - 40000, 0), 0)
        
        # create list of lines from pointer to EOF
        logFileLines = logFile.readlines()
    
    # slice list to include just the last 1000 lines (with debug on W7: 200=10sec, 600=30sec, 800=45sec, 1000=2min40sec)
    logFileLines = logFileLines[-1000:]
    
    # reverse the list so most recent entry is first
    logFileLines.reverse() 
    
    # parse the list (from most recent backwards)
    for logFileIndex, logFileLine in enumerate(logFileLines):

        # find reference to video opening
        if refVideoOpen in logFileLine:
        
            # find start of video file name  
            linePointer = logFileLine.find(refVideoOpen) + len(refVideoOpen)
            
            # read video file name
            videoFileName = logFileLine[linePointer:].rstrip('\n')

            # Now find the FPS
            
            # slice new list at current index
            logFileLines2 = logFileLines[:logFileIndex]

            # reverse list2 so oldest entry is first
            logFileLines2.reverse() 
            
            # parse list2 (from video opening reference forward)
            for logFileLine2 in logFileLines2:

                # find reference to FPS
                if refVideoFPSstart in logFileLine2:
                
                    # find start and end of FPS value
                    linePointerStart = logFileLine2.find(refVideoFPSstart) + len(refVideoFPSstart)
                    linePointerEnd = logFileLine2.find(refVideoFPSend)

                    # read FPS value
                    videoFPSValue = logFileLine2[linePointerStart:linePointerEnd]

                    # truncate FPS to three decimal places
                    decSplit = videoFPSValue.find('.') + 4
                    videoFPSValue = videoFPSValue[0:decSplit]

                    # only save FPS if not 0.000 (seen on one dvd-iso)
                    if videoFPSValue != '0.000':

                        # save FPS for use in setDisplayModeAuto
                        fsconfig.lastDetectedFps = videoFPSValue
                        fsconfig.lastDetectedFile = videoFileName
                        fsconfigutil.saveLastDetectedFps()

                        # found FPS - stop parsing list2
                        break

                    # FPS is 0.000 - treat as not found
                    else:
                        videoFPSValue = None

            # found video open and FPS (if not 0.000) - stop parsing the list
            break
                             
    return videoFileName, videoFPSValue

def getPlatformType():
# function for getting platform type

    osPlatform = sys.platform
    
    if osPlatform == 'win32':
        osVariant = platform.system() + ' ' + platform.release()

    elif osPlatform == 'linux3':
        productBrand = subprocess.Popen(['getprop', 'ro.product.brand'], stdout=subprocess.PIPE).communicate()[0].strip()
        productDevice = subprocess.Popen(['getprop', 'ro.product.device'], stdout=subprocess.PIPE).communicate()[0].strip()
        productName = subprocess.Popen(['getprop', 'ro.product.name'], stdout=subprocess.PIPE).communicate()[0].strip()
        if '720p' in productName: osVariant = productBrand + ' ' + productDevice+' 720p'
        elif '1080p' in productName: osVariant = productBrand + ' ' + productDevice+' 1080p'
        else: osVariant = productBrand + ' ' + productDevice
        
    else:
        osVariant = 'unsupported'
    
    return osPlatform, osVariant

def getDisplayMode():
# function to read the current output mode from display/mode

    modeFile = None
    outputMode = None
    amlogicMode = None
    
    modeFileAndroid = "/sys/class/display/display0.HDMI/mode"
    modeFileWindows = "d:\\x8mode.txt"
 
    if 'SAMSUNG rk3188' in fsconfig.osPlatform:
        modeFile = modeFileAndroid
    elif fsconfig.osPlatform == 'Windows 7':
        modeFile = modeFileWindows 
    else:
        outputMode = 'Unsupported platform.'
        return outputMode, amlogicMode
      
    # check file exists
    if os.path.isfile(modeFile):
        # check file is writable
        try: os.system("chmod 777 "+modeFile)
        except:
			os.system("su -c 'chmod 777 "+modeFile+"'")
			pass
        if os.access(modeFile, os.R_OK):
            with open(modeFile, 'r') as modeFileHandle:      
                amlogicMode = modeFileHandle.readline().strip()
                
                # convert AMLOGIC output mode to more descriptive mode
                if amlogicMode == '1920x1080p-60':
                    outputMode = '1080p-60hz'
                elif amlogicMode == '1920x1080p-50':
                    outputMode = '1080p-50hz'
                elif amlogicMode == '1920x1080p-24':
                    if '1080p' in fsconfig.osPlatform: outputMode = '1080p-24hz'
                    elif '720p' in fsconfig.osPlatform: outputMode = '720p-24hz'
                    else: outputMode = '1080p-24hz'
                elif amlogicMode == '1280x720p-60':
                    outputMode = '720p-60hz'					
                elif amlogicMode == '1280x720p-50':
                    outputMode = '720p-50hz'
                else:
                    outputMode = "unsupported"
                
            if amlogicMode == '':
                outputMode = "invalid"
                amlogicMode = 'Mode file read, but is empty.'
        else:
            outputMode = "invalid"
            amlogicMode = 'Mode file found, but could not read.'                
    else:
        outputMode = "invalid"
        amlogicMode = 'Mode file not found.'

    return outputMode, amlogicMode

def getDisplayModeFileStatus():
# function to check that the display/mode file exists and is writable

    modeFile = None
    fileStatus = None
    
    modeFileAndroid = "/sys/class/display/display0.HDMI/mode"
    modeFileWindows = "d:\\x8mode.txt"
 
    if 'SAMSUNG rk3188' in fsconfig.osPlatform:
        modeFile = modeFileAndroid
    elif fsconfig.osPlatform == 'Windows 7':
        modeFile = modeFileWindows 
    else:
        fileStatus = 'Unsupported platform'
        return modeFile, fileStatus
      
    # check file exists
    if os.path.isfile(modeFile):
        try: os.system("chmod 777 "+modeFile)
        except:
			os.system("su -c 'chmod 777 "+modeFile+"'")
			pass
        # check file is writable
        if os.access(modeFile, os.W_OK):
            fileStatus = 'OK: Frequency switching is supported'
        else:
            fileStatus = 'HDMI mode file is read only'                
    else:
        fileStatus = 'HDMI mode file not found'

    return modeFile, fileStatus

def setDisplayMode(newOutputMode):
    # function to write the current output mode from display/mode

    # check whether display/mode file it writable 
    modeFile, fileStatus = getDisplayModeFileStatus()
     
    # display/mode file is not writable
    if fileStatus[:2] != 'OK':
        setModeStatus = fileStatus
        statusType = 'warn'
 
    # display/mode file is writable
    else:
        
        # convert output mode to a valid AMLOGIC mode
        if newOutputMode == '1080p-60hz':
            newAmlogicMode = '1920x1080p-60'
        elif newOutputMode == '1080p-50hz':
            newAmlogicMode = '1920x1080p-50'
        elif newOutputMode == '1080p-24hz':
            newAmlogicMode = '1920x1080p-24'
        elif newOutputMode == '720p-60hz':
            newAmlogicMode = '1280x720p-60'
        elif newOutputMode == '720p-50hz':
            newAmlogicMode = '1280x720p-50'
        elif newOutputMode == '720p-24hz':
            newAmlogicMode = '1920x1080p-24'			
        else:
            setModeStatus = 'Unsupported mode requested.'
            statusType = 'warn'
            return setModeStatus, statusType
          
        # check current display mode setting
        currentOutputMode, currentAmlogicMode = getDisplayMode()
               
        # get current resolution
        resSplit = currentOutputMode.find('-')
        currentRes = currentOutputMode[0:resSplit]

        # get new resolution
        resSplit = newOutputMode.find('-')
        newRes = newOutputMode[0:resSplit]
        
        # get new frequency
        freqSplit = newOutputMode.find('-') + 1
        newFreq = newOutputMode[freqSplit:len(newOutputMode)]
    
        # current output mode is the same as new output mode
        if currentOutputMode == newOutputMode:
            setModeStatus = 'Frequency already set to ' + newFreq 
            statusType = 'warn'
       
        # current output mode is different to new output mode
        else:
            
            # new resolution is different to current resolution
            if newRes != currentRes:
                setModeStatus = 'Resolution changed, please reconfigure'
                statusType = 'warn'
             
            # new resolution is the same as the current resolution
            else: 
             
                fsconfigutil.loadLastFreqChangeSetting()
             
                # check that at least 4 seconds has elapsed since the last frequency change
                secToNextFreqChange = 4 - (int(time.time()) - fsconfig.lastFreqChange)
                if secToNextFreqChange > 1:
                    setModeStatus = 'Stand-down ' + str(secToNextFreqChange) + ' seconds'               
                    statusType = 'warn'
                elif secToNextFreqChange == 1:
                    setModeStatus = 'Stand-down ' + str(secToNextFreqChange) + ' second' 
                    statusType = 'warn'

                # more than 4 seconds has elapsed since the last frequency change 
                else:
                    # set new display mode
                    try:
						with open(modeFile, 'w') as modeFileHandle: modeFileHandle.write(newAmlogicMode)					
                    except:
						try: os.system("chmod 777 "+modeFile)
						except: pass
						try: os.system("echo "+newAmlogicMode+" > "+modeFile)
						except:
							os.system("su -c 'chmod 777 "+modeFile+"'")
							os.system("su -c 'echo "+newAmlogicMode+" > "+modeFile+"'")
							pass
						pass
						
                    # save time display mode was changed
                    fsconfig.lastFreqChange = int(time.time())
                    fsconfigutil.saveLastFreqChangeSetting()
                    
                    setModeStatus = 'Frequency changed to ' + newFreq
                    statusType = 'info'
     
    return setModeStatus, statusType

def getCurrentFPS():
    
    # get currently playing video
    videoFileNamePlay = getPlayingVideo()

    # playing video not detected
    if videoFileNamePlay is None:
        setModeStatus = 'No playing video detected.'
        statusType = 'warn'
    
    # playing video detected
    else:

        # check last detected info (before reading the log file)
        fsconfigutil.loadLastDetectedFps()
         
        # last detected file name matches currently playing video, so use last detected FPS
        if fsconfig.lastDetectedFile == videoFileNamePlay:
            videoFileNameLog = fsconfig.lastDetectedFile
            videoFPSValue = fsconfig.lastDetectedFps
        
        # FPS not stored as last detected FPS
        else:
            # read FPS from XBMC log
            videoFileNameLog, videoFPSValue = getSourceFPS()
        
        # FPS not detected
        if videoFPSValue is None:
            setModeStatus = 'Failed to get source framerate.'
            statusType = 'warn'
        
        # FPS detected
        else:
                
            # log file name doesn't match currently playing video
            if videoFileNameLog != videoFileNamePlay:
                setModeStatus = 'Found source framerate for wrong video file.'
                statusType = 'warn'
        
            # log file name matches currently playing video
            else:
                setModeStatus = videoFPSValue
                statusType = 'ok'
    
    return setModeStatus, statusType

def setDisplayModeAuto():
    # function to write the current output mode based on FPS to Frequency configuration

    # check current display mode setting
    currentOutputMode, currentAmlogicMode = getDisplayMode()
    
    if currentOutputMode == 'unsupported':
        setModeStatus = 'Unsupported resolution: ' + currentAmlogicMode           
        statusType = 'warn'
            
    elif currentOutputMode == 'invalid':
        setModeStatus = 'Error, unexpected mode: ' + currentAmlogicMode       
        statusType = 'warn'
        
    else:
        # load auto sync settings
        fsconfigutil.loadAutoSyncSettings()
        
        # get current resolution
        resSplit = currentOutputMode.find('-')
        currentRes = currentOutputMode[0:resSplit]
            
        mode60hz = currentRes + '-60hz'
        mode50hz = currentRes + '-50hz'
        mode24hz = currentRes + '-24hz'
        
        autoSync = []

        syncConfig = []        
        if fsconfig.radioAuto60hz:
            syncConfig.extend([(fsconfig.edit60hzFps1, mode60hz),
                               (fsconfig.edit60hzFps2, mode60hz), 
                               (fsconfig.edit60hzFps3, mode60hz), 
                               (fsconfig.edit60hzFps4, mode60hz)])

        if fsconfig.radioAuto50hz:
            syncConfig.extend([(fsconfig.edit50hzFps1, mode50hz), 
                               (fsconfig.edit50hzFps2, mode50hz), 
                               (fsconfig.edit50hzFps3, mode50hz), 
                               (fsconfig.edit50hzFps4, mode50hz)])
             
        if fsconfig.radioAuto24hz:
            syncConfig.extend([(fsconfig.edit24hzFps1, mode24hz), 
                               (fsconfig.edit24hzFps2, mode24hz),
                               (fsconfig.edit24hzFps3, mode24hz),
                               (fsconfig.edit24hzFps4, mode24hz)])        

        # build auto sync list
        for (syncFPS, syncMode) in syncConfig:
            if syncFPS != '':
                autoSync.insert(0, (syncFPS, syncMode))

        if not autoSync:
            setModeStatus = 'No FPS to frequency configuration defined'       
            statusType = 'warn'

        else:
    
            # get FPS of currently playing video
            setModeStatus, statusType = getCurrentFPS()
            
            if statusType == 'ok':
                videoFPSValue = setModeStatus
    
                # search auto sync list for FPS
                fpsFoundInSyncList = False
                for (syncFPS, syncFreq) in autoSync:
                    if syncFPS == videoFPSValue:
                        fpsFoundInSyncList = True
                        break
                
                # FPS not found configured in auto sync list
                if not fpsFoundInSyncList:
                    setModeStatus = 'Source framerate not configured: ' + videoFPSValue                        
                    statusType = 'warn'

                # FPS found in auto sync list       
                else:
                    # set the output mode
                    setModeStatus, statusType = setDisplayMode(syncFreq)                    
                    # check for unsupported mode '720p-24hz'
                    #if syncFreq == '720p-24hz':
                    #    setModeStatus = syncFreq + ' is not supported'
                    #    statusType = 'warn'                      

                    #else:
                        # set the output mode
                    #    setModeStatus, statusType = setDisplayMode(syncFreq)
                            
    return setModeStatus, statusType

def mapKey(keyScope, keyMappings):
# function for saving key mappings - rewrites entire zswitch.xml file

    # build key map
    mapStart = '<keymap><' + keyScope + '><keyboard>'
    keyStart = '<key id="'
    keyMiddle = '">runaddon(script.video.fswitchRK,'
    keyEnd = ')</key>'
    mapEnd = '</keyboard></global></keymap>'  
    
    keyMap = mapStart
    for (keyCode, keyFunction) in keyMappings:
        keyMap = keyMap + keyStart + keyCode + keyMiddle + keyFunction + keyEnd
    keyMap = keyMap + mapEnd
       
    # key map file
    keymapFolder = xbmc.translatePath('special://userdata/keymaps')
    keymapFile = os.path.join(keymapFolder, 'zswitch.xml')
 
    # create keymap folder if it doesn't already exist
    if not os.path.exists(keymapFolder):
        os.makedirs(keymapFolder)
         
    # create or overwrite keymap file
    try:
        with open(keymapFile, 'w') as keymapFileHandle: 
            keymapFileHandle.write(keyMap)
        mapKeyStatus = 'Keys activated'
    except Exception:
        mapKeyStatus = 'Failed to activate keys'
          
    # load updated key maps
    xbmc.executebuiltin('action(reloadkeymaps)')

    return mapKeyStatus

def mapKeyReset():
    
    # key map file
    keymapFolder = xbmc.translatePath('special://userdata/keymaps')
    keymapFile = os.path.join(keymapFolder, 'zswitch.xml')

    # check file exists
    if not os.path.isfile(keymapFile):
        mapKeyResetStatus = 'No keys currently active'
        return mapKeyResetStatus
        
    # delete key map file
    try:
        os.remove(keymapFile)
        mapKeyResetStatus = 'Keys deactivated'
    except Exception:
        mapKeyResetStatus = 'Failed to deactivate keys'

    # load updated key maps
    xbmc.executebuiltin('action(reloadkeymaps)')

    return mapKeyResetStatus

def mapKeyActive():
   
    # key map file
    keymapFolder = xbmc.translatePath('special://userdata/keymaps')
    keymapFile = os.path.join(keymapFolder, 'zswitch.xml')

    # check file exists
    return os.path.isfile(keymapFile)

def getPlayingVideo():
# function to get the file name of the currently playing video

    if xbmc.Player().isPlayingVideo():
        videoFileName = xbmc.Player().getPlayingFile() 
    else:
        videoFileName = None
        
    return videoFileName
