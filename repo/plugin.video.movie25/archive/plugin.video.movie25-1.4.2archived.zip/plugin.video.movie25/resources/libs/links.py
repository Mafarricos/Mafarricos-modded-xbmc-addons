# -*- coding: UTF-8 -*-
# by Mafarricos
# email: MafaStudios@gmail.com
# This program is free software: GNU General Public License

class link:
	def __init__(self):
		import base64
		self.movie25url = base64.urlsafe_b64decode('aHR0cDovL3d3dy5tb3ZpZTI1LmNtLw==')
		self.HMlabel = base64.urlsafe_b64decode('SGFja2VyTWlscyBTdGFzaA==')
		self.HM = base64.urlsafe_b64decode('aHR0cHM6Ly9yYXcuZ2l0aHViLmNvbS9IYWNrZXJNaWwvSGFja2VyTWlsc01vdmllU3Rhc2gvbWFzdGVyL0RpcmVjdG9yeS9IYWNrZXJNaWxfRGlyZWN0b3J5LnhtbA==')
		self.HMHD = base64.urlsafe_b64decode('aHR0cHM6Ly9yYXcuZ2l0aHViLmNvbS9IYWNrZXJNaWwvSGFja2VyTWlsc01vdmllU3Rhc2gvbWFzdGVyL01vdmllcy9IRC54bWw=')
		self.HM1080 = base64.urlsafe_b64decode('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0hhY2tlck1pbC9IYWNrZXJNaWxzTW92aWVTdGFzaC9tYXN0ZXIvTW92aWVzLzEwODBQLnhtbA==')
		self.S1982label = base64.urlsafe_b64decode('U3RhYWVsIDE5ODI=')
		self.S1982 = base64.urlsafe_b64decode('aHR0cDovL3R1emxhLndhdGNoa29kaS5jb20=')
		self.demonlabel = base64.urlsafe_b64decode('RGVtb244OCBNb3ZpZXM==')
		self.demon = base64.urlsafe_b64decode('aHR0cDovL2NhaXJvLndhdGNoa29kaS5jb20=')
		self.onelabel = base64.urlsafe_b64decode('T05FMjQyNDE1')
		self.one = base64.urlsafe_b64decode('aHR0cDovL2dpYnJhbHRhci53YXRjaGtvZGkuY29t')
		self.kimolabel = base64.urlsafe_b64decode('SzFNMDUncyBTdHJlYW1z')
		self.kimo = base64.urlsafe_b64decode('aHR0cHM6Ly9yYXcuZ2l0aHViLmNvbS94Ym1jdGFsay9NYXNoVXBLMW0wNS9tYXN0ZXIvazFtMDVfbWFzaHVwRGlyZWN0b3J5LnhtbA==')		
		self.buzzylabel = base64.urlsafe_b64decode('QnV6enkgU3BvcnRz')
		self.buzzy = base64.urlsafe_b64decode('aHR0cDovL2JhbmphbHVrYS53YXRjaGtvZGkuY29t')
		self.tnpblabel = base64.urlsafe_b64decode('VE5QQg==')
		self.tnpb = base64.urlsafe_b64decode('aHR0cDovL3plbmljYS53YXRjaGtvZGkuY29t')
		
		